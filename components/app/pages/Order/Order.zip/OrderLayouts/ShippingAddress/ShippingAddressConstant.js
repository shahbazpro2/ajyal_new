export const NEXT = "NEXT";
export const PREV = "PREV";
export const VERIFY_PHONE = 1;
export const CHANGE_PHONE = 2;
export const SELECT_ADDRESS = 3;
export const GET_ADDRESS_DETAIL = 4;
export const COMPLETE = "COMPLETE";
