import React from 'react';

export const orderContext = React.createContext();