export const SHIPPING = 1;
export  const PAYMENT = 2;
export const ORDERPLACED = 3;
export const MAXSTEP = 3;
export const NEXT = "NEXT";
export const PREV = "PREV";
export const COMPLETE_AND_NEXT = "COMPLETE_AND_NEXT";